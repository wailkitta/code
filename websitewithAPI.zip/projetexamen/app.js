const express = require("express");
const morgan = require("morgan");
const axios = require("axios");
const { MongoClient, ObjectId } = require("mongodb");
//const MongoClient = require("mongodb").MongoClient;

// express app
const app = express();
const port = 3000;

app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));
const apiKey = "41AA96TAMAFU6OS7";
const symbol = "IBM";
const uri = "mongodb://localhost:27017";
const client = new MongoClient(uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

async function connectToDatabase() {
  try {
    await client.connect();
    console.log("Connexion à la base de données réussie");
  } catch (err) {
    console.error("Erreur lors de la connexion à la base de données:", err);
  }
}
connectToDatabase();

const database = client.db("node-tuts");
const collection = database.collection("blogs");

app.get("/", (req, res) => {
  res.render("index"); // redirection vers cette url
});

app.get("/about", (req, res) => {
  res.render("about", { title: "About" }); //pour afficher la vue "about.ejs"
});

//route pour afficher la table
app.get("/table", async (req, res) => {
  try {
    const response = await axios.get(
      `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=${symbol}&outputsize=full&apikey=${apiKey}`
    );
    const newData = {
      Date: " ",
      Open: " ",
      High: " ",
      Low: " ",
      Close: " ",
      Volume: " ",
    };
    const stockData = response.data["Time Series (Daily)"];
    const insertedData = await collection.findOne({});
    if (!insertedData) {
      // si elles n'ont pas été inséré alors on les insère
      collection
        .insertOne(stockData)
        .then((result) => {
          console.log("database inséré");
        })
        .catch((err) => {
          console.log(err);
          // Gérez l'erreur et envoyez une réponse appropriée au client
          res.status(500).send("Une erreur s'est produite");
        });
    }
    const id = req.params.id;
    collection
      .find({ _id: new ObjectId(id) })
      .sort({ createdAt: -1 })
      .toArray()
      .then((result) => {
        res.render("table", {
          stockData: stockData,
          newData: newData,
        });
      })
      .catch((err) => {
        console.log(err);
      });
  } catch (error) {
    console.log(error);
    // Gérez l'erreur et envoyez une réponse appropriée au client
    res.status(500).send("Une erreur s'est produite");
  }
});
//route pour inserer une table avec la requete POST
app.post("/table", async (req, res) => {
  const response = await axios.get(
    `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=${symbol}&outputsize=full&apikey=${apiKey}`
  );

  const stockData = response.data["Time Series (Daily)"];
  const insertedData = await collection.findOne({});
  if (!insertedData) {
    // si elles n'ont pas été inséré alors on les insère
    collection
      .insertOne(stockData)
      .then((result) => {
        console.log("database inséré");
      })
      .catch((err) => {
        console.log(err);
        // Gérez l'erreur et envoyez une réponse appropriée au client
        res.status(500).send("Une erreur s'est produite");
      });
  }
  const newData = {
    Date: req.body.Date,
    Open: req.body.Open,
    High: req.body.High,
    Low: req.body.Low,
    Close: req.body.Close,
    Volume: req.body.Volume,
  };

  collection
    .insertOne(newData)
    .then((result) => {
      res.render("table", {
        newData: newData,
        stockData: stockData,
      }); // Rediriger vers la page des blogs après l'insertion
    })
    .catch((err) => {
      console.log(err);
      res.status(500).send("Une erreur s'est produite");
    });
});
//route pour affichage de la création de table
app.get("/table/create", (req, res) => {
  res.render("create", { title: "Create a new Blog" });
});
// route pour montrer update
app.get("/table/:id", async (req, res) => {
  const id = req.params.id;
  try {
    // Récupérer les données de la base de données en fonction de l'ID
    const data = await collection.findOne({ _id: new ObjectId(id) });

    if (data) {
      // Afficher la vue "edit" avec les données récupérées
      res.render("edit", { data: data });
    } else {
      console.log("Aucune donnée trouvée pour cet ID.");
      res.status(404).send("Aucune donnée trouvée pour cet ID.");
    }
  } catch (error) {
    console.log("Erreur lors de la récupération des données:", error);
    res.status(500).send("Erreur lors de la récupération des données.");
  }
});
//route pour update les éléments
app.post("/table/:id", async (req, res) => {
  const id = req.params.id;
  const updatedData = {
    Date: req.body.Date,
    Open: req.body.Open,
    High: req.body.High,
    Low: req.body.Low,
    Close: req.body.Close,
    Volume: req.body.Volume,
  };

  try {
    // Mise à jour des données en fonction de l'ID
    await collection.updateOne(
      { _id: new ObjectId(id) },
      { $set: updatedData }
    );

    // Rediriger vers la page de liste des éléments ou afficher un message de confirmation
    res.redirect("/table");
  } catch (error) {
    console.log("Erreur lors de la mise à jour des données:", error);
    res.status(500).send("Erreur lors de la mise à jour des données.");
  }
});
//method delete
app.delete("/table/:id", (req, res) => {
  const id = req.params.id;
  collection
    .deleteOne({ _id: new ObjectId(id) })
    .then((result) => {
      res.json({ redirect: "/table" });
    })
    .catch((err) => {
      console.log(err);
    });
});

//404 page
/*
app.use((req, res) => {
  res.status(404).render("404", { title: "404" }); //pour afficher la vue "404.ejs"
});
*/
app.listen(port, () => {
  console.log(`Serveur en cours d'exécution sur le port ${port}`);
});
