const MongoClient = require("mongodb").MongoClient;

// Connexion à la base de données
const uri = "mongodb://localhost:27017"; // Exemple d'URL de connexion
const client = new MongoClient(uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

async function createDocument() {
  try {
    await client.connect();

    const database = client.db("nom-de-la-base-de-donnees");
    const collection = database.collection("nom-de-la-collection");

    // Insérer un document
    const document = { title: String, snippet: String, body: String };
    const result = await collection.insertOne(document); //await collection.insertOne(document) est une méthode fournie par le driver MongoDB pour Node.js qui permet d'insérer un document dans une collection de la base de données MongoDB.

    console.log("Document inséré avec l'ID :", result.insertedId); // result.insertedId => génère automatiquement un champ _id pour ce document, qui est utilisé comme identifiant unique.
  } finally {
    // Fermer la connexion après utilisation
    await client.close();
  }
}

createDocument().catch(console.error);
