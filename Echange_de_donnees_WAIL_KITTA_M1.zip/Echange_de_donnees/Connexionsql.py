import mysql.connector;
import xml.etree.ElementTree as ET
from lxml import etree
import csv
import lxml.etree as Et

#Connexion SQL
connexion = mysql.connector.connect(user ='root',password='isib',host='localhost',database='soccer')

#Création de curseur pour éxecuter les rêquetes SQL
cursor = connexion.cursor()

#Execution d'une rêquete SELECT pour récupérer les données de la table
query = "SELECT * FROM soccer_table"
cursor.execute(query)

#récuperer les résultats de la rêquete
results = cursor.fetchall()





# Créer un élément racine pour le document XML
root = ET.Element("XMLSOCCER.COM")

# On parcours les lignes de résultat et on crée des éléments XML pour chaque ligne
for row in results:
    # Créer un élément pour chaque ligne
    row_element = ET.SubElement(root, "Topscorer")

    # Parcourir les colonnes de chaque ligne
    for i, col_name in enumerate(cursor.column_names):
        # Récupérer la valeur de la colonne dans la ligne actuelle
        col_value = row[i]

        # Créer un élément pour chaque colonne avec le nom de la colonne comme balise
        col_element = ET.SubElement(row_element, col_name)
        col_element.text = str(col_value)

row_element2 = ET.SubElement(root, "AccountInformation")
row_element2.text = "Data requested at xx-xx-xxxx xx:xx:xx from xxx.xxx.xxx.xxx, Username: xxxx. Your current supscription runs out on xx-xx-xxxx xx:xx:xx."
# Créer un objet ElementTree à partir de l'élément racine
tree = ET.ElementTree(root)

# Enregistrer le document XML dans un fichier
tree.write("soccer.xml")
print("xml créé")
# Fermer le curseur et la connexion à la base de données
cursor.close()
connexion.close()
# Charger le fichier XML
xml_file = "soccer.xml"

# Charger le fichier XSD
xsd_file = "soccer.xsd"

# Créer un parseur XSD
schema = etree.XMLSchema(file=xsd_file)

# Créer un parseur XML
parser = etree.XMLParser(schema=schema)

try:
    # Parcourir le fichier XML et effectuer la validation
    tree = etree.parse(xml_file, parser)
    print("Le fichier XML est valide par rapport au schéma XSD.")


    # C'est pour analyser un fichier XML et créer un objet ElementTree
    tree = ET.parse(xml_file)

    # C'est pour obtenir l'élément racine du fichier XML
    root = tree.getroot()

    # On convertit la racine élément en string
    xml_string = ET.tostring(root, encoding="utf-8").decode("utf-8")

    # On ouvre le CSV
    csv_file = open("soccer.csv", "w", newline="")

    # On crée le fichier CSV
    csv_writer = csv.writer(csv_file)

    # Écriture de l'en-tête du fichier CSV
    csv_writer.writerow(
        ["Rank", "Name", "TeamName", "Team_Id", "Nationality", "Goals", "FirstScorer", "Penalties", "MissedPenalties"])

    # Extraction des données du XML et écriture des lignes dans le fichier CSV
    for topscorer in root.findall("Topscorer"):
        rank = topscorer.find("Rank").text
        name = topscorer.find("Name").text
        team_name = topscorer.find("TeamName").text
        team_id = topscorer.find("Team_Id").text
        nationality = topscorer.find("Nationality").text
        goals = topscorer.find("Goals").text
        first_scorer = topscorer.find("FirstScorer").text
        penalties = topscorer.find("Penalties").text
        missed_penalties = topscorer.find("MissedPenalties").text

        csv_writer.writerow(
            [rank, name, team_name, team_id, nationality, goals, first_scorer, penalties, missed_penalties])
    print("Conversion XML vers CSV terminée.")
    # On ferme le fichier CSV
    csv_file.close()



    # C'est pour analyser un fichier XML et créer un objet ElementTree
    tree = Et.parse(xml_file)

    # C'est pour obtenir l'élément racine du fichier XML
    root = tree.getroot()

    # On convertit la racine élément en string
    xml_data = Et.tostring(root, encoding="utf-8").decode("utf-8")

    xslt_file = "soccer.xslt"

    # C'est pour analyser un fichier XML et créer un objet ElementTree
    xslt_tree = Et.parse(xslt_file)
    # permet d'effectuer des transformations XSLT sur des documents XML à l'aide d'une feuille de style XSLT
    xslt_transform = Et.XSLT(xslt_tree)

    # Analyse des données XML
    xml_tree = Et.fromstring(xml_data)

    # Appliquer la transformation XSLT
    html_tree = xslt_transform(xml_tree)

    # Sérialise la sortie HTML
    html_string = Et.tostring(html_tree, pretty_print=True, encoding="utf-8").decode("utf-8")

    # Enregistrer le HTML dans un fichier
    html_file = "soccer.html"
    with open(html_file, "w") as f:
        f.write(html_string)

    print("fichier HTML crée")
except etree.XMLSyntaxError as e:
    print("Le fichier XML est invalide par rapport au schéma XSD.")
    print(e)