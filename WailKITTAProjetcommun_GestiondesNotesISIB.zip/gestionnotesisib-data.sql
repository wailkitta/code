SET SQL_SAFE_UPDATES=0;

DELETE FROM UE;
DELETE FROM Cours;




DELETE FROM Etudiant;

DELETE FROM Professeurs;
DELETE FROM Sessions;
DELETE FROM Résultats;
DELETE FROM CAVP;
DELETE FROM appartient;
DELETE FROM participe;

#UE

INSERT INTO UE(NumberUE,NameUE,CreditsUE,HeuresUE) 
VALUES ('1ZZ0200','MATHEMATIQUES I',6,78);
INSERT INTO UE(NumberUE,NameUE,CreditsUE,HeuresUE) 
VALUES ('2ZZ1100','CHIMIE APPLIQUEE',5,60);
INSERT INTO UE(NumberUE,NameUE,CreditsUE,HeuresUE)  
VALUES ('2ZZ1300','ELECTRONIQUE & INFORMATIQUE I',7,84);
INSERT INTO UE(NumberUE,NameUE,CreditsUE,HeuresUE) 
VALUES ('3CH0400','BIOCHIMIE & CHIMIE PHYSIQUE',4,48);
INSERT INTO UE(NumberUE,NameUE,CreditsUE,HeuresUE)  
VALUES ('3EM1000','MATERIAUX & STRUCTURES II',7,84);
INSERT INTO UE(NumberUE,NameUE,CreditsUE,HeuresUE) 
 VALUES ('3GE0400','RESEAUX & SYSTEMES INFORMATIQUES',4,48);
INSERT INTO UE(NumberUE,NameUE,CreditsUE,HeuresUE) 
 VALUES ('3GT0500','OPTIQUE',4,48);
INSERT INTO UE(NumberUE,NameUE,CreditsUE,HeuresUE) 
 VALUES ('3YY0100','INSTRUMENTATION ELECTRONIQUE',4,48);
INSERT INTO UE(NumberUE,NameUE,CreditsUE,HeuresUE) 
 VALUES ('3YY0600','AUTOMATIQUE DE BASE',4,52);
INSERT INTO UE(NumberUE,NameUE,CreditsUE,HeuresUE) 
 VALUES ('3ZZ0400','ELECTRONIQUE & INFORMATIQUE III',7,88);
INSERT INTO UE(NumberUE,NameUE,CreditsUE,HeuresUE) 
 VALUES ('3ZZ0500','ELECTROTECHNIQUE & ELECTRICITE APPLIQUEE',6,76);

 
#Etudiants
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10002,'LIEGEOIS','Florent ','rue de l\'Abbaye  20','1992-05-15','M');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10007,'CUVELIER','Jonas','rue Baron Horta 10','1993-02-25','M');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10010,'BAX','Luc ','rue Camusel 30','1991-11-01','M');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10016,'MELLOUL KHAYARI ','Halima','rue Antoine Dansaert 50','1994-08-08','F');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10028,'MUSSAYEVA ','Goulmira ','rue de l\'Enseignement 25','1994-01-20','F');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10030,'BRYANT CANO','Sofia ','rue de Flandre 10','1993-03-18','F');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10031,'VAN STAPPEN','Laura ','rue des Guildes  120','1995-10-29','F');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10033,'VANDERSTRAETEN ','Emilie ','rue Haute 80','1995-12-17','F');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10038,'NOËL ','Clément ','boulevard Émile Jacqmain 38','1995-07-06','M');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10039,'TORFS ','Arnaud ','rue de Laeken 03','1995-04-21','M');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10046,'NDIKUMANA ','Scotty ','rue du Marais','1994-09-29','M');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10049,'HUBERT ','Alexis ','rue de Nancy 45','1996-06-12','M');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10054,'DAVE ','David ','rue Auguste Orts 57','1996-10-30','M');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
 VALUES (10060,'DEREAU ','Benjamin ','rue des Palais 79','1996-03-09','M');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10069,'OUKIL ','Souhail ','rue de la Régence 90','1996-11-16','M');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10070,'ZECH ','Damien ','rue Saint-Ghislain 120','1997-02-28','M');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10072,'MASSART ','Mathis ','rue Terre-Neuve 47','1997-05-19','M');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10087,'DE DECKER ','Julien ','rue d\'Assaut','1996-12-31','M');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10091,'HORVATH ','Laurent ','rue Bodenbroek 88','1997-01-22','M');
INSERT INTO etudiant(NumberEtud,NomEtud,PrénomEtud,AdresseEtud,DatedeNaissEtud,SexeEtud)
VALUES (10097,'CAMPENART ','Dylan ','rue du Chasseur 97','1998-04-03','M');


#Professeurs
INSERT INTO professeurs(NomProf,PrenomProf,ProfAdresse,SexeProf)
 VALUES ('BAIBOUN','Nadir','rue du Marché aux Peaux','M');
INSERT INTO professeurs(NomProf,PrenomProf,ProfAdresse,SexeProf)
 VALUES ('CLAESSENS ','Nicolas','rue a la Spinette 10','M');
INSERT INTO professeurs(NomProf,PrenomProf,ProfAdresse,SexeProf)
 VALUES ('DE HEYN','Véronique','rue a la Croix 35','F');
INSERT INTO professeurs(NomProf,PrenomProf,ProfAdresse,SexeProf)
 VALUES ('DEGEEST ','Alexandra ','rue Stephenson 10','F');
INSERT INTO professeurs(NomProf,PrenomProf,ProfAdresse,SexeProf)
 VALUES ('FRAIPONT','Céline','rue a la corne du pré 55','F');
INSERT INTO professeurs(NomProf,PrenomProf,ProfAdresse,SexeProf)
 VALUES ('GARCIA ACEVEDO','Salvador','rue de Montserrat 5','M');
INSERT INTO professeurs(NomProf,PrenomProf,ProfAdresse,SexeProf)
 VALUES ('GROBET','Damien','rue de la Montagne 34','M');
INSERT INTO professeurs(NomProf,PrenomProf,ProfAdresse,SexeProf)
 VALUES ('LE VAILLANT','Gwendal','rue des Palais 80','M');
INSERT INTO professeurs(NomProf,PrenomProf,ProfAdresse,SexeProf)
VALUES ('LEBOUTTE','Éric','rue a l\'eau 5','M');
INSERT INTO professeurs(NomProf,PrenomProf,ProfAdresse,SexeProf) 
VALUES ('MATTENS ','Jean-Michel','rue du Président 55','M');
INSERT INTO professeurs(NomProf,PrenomProf,ProfAdresse,SexeProf)
 VALUES ('PEETERS','Agnès','rue Des Glacis 60','F');
INSERT INTO professeurs(NomProf,PrenomProf,ProfAdresse,SexeProf)
VALUES ('RODRIGUES E SOUSA','Abilio Sergio ','rue Wolfsweg 10','M');
INSERT INTO professeurs(NomProf,PrenomProf,ProfAdresse,SexeProf)
 VALUES ('SEVERS ','Thierry','rue des Sables 30','M');
INSERT INTO professeurs(NomProf,PrenomProf,ProfAdresse,SexeProf)
 VALUES ('VAN BUYLAERE','Françoise','rue des Minimes 26','F');
INSERT INTO professeurs(NomProf,PrenomProf,ProfAdresse,SexeProf)
 VALUES ('VANDEN CRUYCE','Patricia','rue a la Fontaine 20','F');
INSERT INTO professeurs(NomProf,PrenomProf,ProfAdresse,SexeProf)
 VALUES ('VANDERSCHUREN','Anne ','rue a prumî molin 27','F');

#Sessions

INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('1-3ZZ0502',2020);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('1-2ZZ1101',2019);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('1-1ZZ0202',2018);
INSERT INTO Sessions (NuméroSess,Année) 
 VALUES ('1-2ZZ1301',2019);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('1-3ZZ0402',2020);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('1-3YY0102',2020);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('1-3ZZ0403',2020);
INSERT INTO Sessions (NuméroSess,Année)  
VALUES ('1-3ZZ0404',2020);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('1-3YY0101',2020);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('1-3ZZ0401',2020);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('1-2ZZ1303',2019);
INSERT INTO Sessions (NuméroSess,Année) 
 VALUES ('1-2ZZ1302',2019);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('1-3ZZ0501',2020);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('1-3ZZ0503',2020);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('1-1ZZ0201',2018);
INSERT INTO Sessions (NuméroSess,Année)  
 VALUES ('1-2ZZ1102',2019);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('2-3ZZ0602',2020);
INSERT INTO Sessions (NuméroSess,Année)  
VALUES ('2-3CH0401',2020);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('2-3CH0402',2020);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('2-3ZZ0601',2020);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('2-3EM1002',2020);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('2-3EM1003',2020);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('2-3EM1001',2020);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('2-3GT0501',2020);
INSERT INTO Sessions (NuméroSess,Année)  
VALUES ('2-3GT0502',2020);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('2-3GT0503',2020);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('2-3GE0401',2020);
INSERT INTO Sessions (NuméroSess,Année) 
VALUES ('2-3GE0402',2020);


#cours
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
 VALUES ('1ZZ0201','Mathématiques 1',42,3,'1ZZ0200','1-1ZZ0201');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('1ZZ0202','Exercices de mathématiques 1',36,3,'1ZZ0200','1-1ZZ0202');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
 VALUES ('2ZZ1101','Biologie & environnement',24,2,'2ZZ1100','1-2ZZ1101');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('2ZZ1102','Chimie & industrie',36,3,'2ZZ1100','1-2ZZ1102');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('2ZZ1301','Electronique numérique',36,3,'2ZZ1300','1-2ZZ1301');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('2ZZ1302','Techniques informatiques 2',24,2,'2ZZ1300','1-2ZZ1302');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('2ZZ1303','Laboratoire de techniques informatiques 1',24,2,'2ZZ1300','1-2ZZ1303');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3CH0401','Biochimie & microbiochimie',12,1,'3CH0400','2-3CH0401');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3CH0402','Chimie physique',36,3,'3CH0400','2-3CH0402');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3EM1001','Compléments de calcul des structures',36,3,'3EM1000','2-3EM1001');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3EM1002','Compléments de science des matériaux',24,2,'3EM1000','2-3EM1002');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3EM1003','Laboratoire de matériaux & structures ',24,2,'3EM1000','2-3EM1003');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3GE0401','Réseaux & systèmes informatiques ',24,2,'3GE0400','2-3GE0401');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3GE0402','Laboratoire de réseaux & systèmes informatiques ',24,2,'3GE0400','2-3GE0402');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3GT0501','Optique',24,2,'3GT0500','2-3GT0501');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3GT0502','Optique appliquée',12,1,'3GT0500','2-3GT0502');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3GT0503','Laboratoire d\'optique ',12,1,'3GT0500','2-3GT0503');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3YY0101','Instrumentation électronique',12,1,'3YY0100','1-3YY0101');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3YY0102','Laboratoire d\'instrumentation électronique',36,3,'3YY0100','1-3YY0102');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3ZZ0401','Electronique',24,2,'3ZZ0400','1-3ZZ0401');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
 VALUES ('3ZZ0402','Electronique de puissance',12,1,'3ZZ0400','1-3ZZ0402');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
 VALUES ('3ZZ0403','Laboratoire d\'électronique 1',24,2,'3ZZ0400','1-3ZZ0403');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3ZZ0404','Laboratoire de techniques informatiques 3 ',28,2,'3ZZ0400','1-3ZZ0404');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3ZZ0501','Electrotechnique',24,2,'3ZZ0500','1-3ZZ0501');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3ZZ0502','Laboratoire d’électrotechnique',28,2,'3ZZ0500','1-3ZZ0502');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3ZZ0503','Energies renouvelables',24,2,'3ZZ0500','1-3ZZ0503');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3ZZ0601','Automatique de base',28,2,'3YY0600','2-3ZZ0601');
INSERT INTO Cours (NumberAA,NameAA,Hours,CreditsAA,UNumberUE,SNuméroSess)
VALUES ('3ZZ0602','Laboratoire d’automatique de base',24,2,'3YY0600','2-3ZZ0602');


#partcipe
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('1-3ZZ0502','BAIBOUN','Nadir');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('1-2ZZ1101','CLAESSENS ','Nicolas');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('1-1ZZ0202','DE HEYN','Véronique');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('1-2ZZ1301','DEGEEST ','Alexandra ');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('1-3ZZ0402','DEGEEST ','Alexandra ');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('1-3YY0102','GARCIA ACEVEDO','Salvador');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('1-3ZZ0403','GARCIA ACEVEDO','Salvador');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('1-3ZZ0404','GROBET','Damien');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('1-3YY0101','LE VAILLANT','Gwendal');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('1-3ZZ0401','LE VAILLANT','Gwendal');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('1-2ZZ1303','MATTENS ','Jean-Michel');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('1-2ZZ1302','SEVERS ','Thierry');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('1-3ZZ0501','VAN BUYLAERE','Françoise');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('1-3ZZ0503','VAN BUYLAERE','Françoise');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('1-1ZZ0201','VANDEN CRUYCE','Patricia');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('1-2ZZ1102','VANDERSCHUREN','Anne ');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('2-3ZZ0602','BAIBOUN','Nadir');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('2-3CH0401','CLAESSENS ','Nicolas');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('2-3CH0402','CLAESSENS ','Nicolas');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('2-3ZZ0601','DEGEEST ','Alexandra ');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('2-3EM1002','FRAIPONT','Céline');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('2-3EM1003','FRAIPONT','Céline');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('2-3EM1001','LEBOUTTE','Éric');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('2-3GT0501','PEETERS','Agnès');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('2-3GT0502','PEETERS','Agnès');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('2-3GT0503','PEETERS','Agnès');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('2-3GE0401','RODRIGUES E SOUSA','Abilio Sergio ');
INSERT INTO participe (SNuméroSess,PNomProf,PPrenomProf) 
VALUES ('2-3GE0402','RODRIGUES E SOUSA','Abilio Sergio ');

#Résultats
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-1ZZ0202',10002,12);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-1ZZ0202',10007,14);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-1ZZ0202',10010,9.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-1ZZ0202',10016,5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-1ZZ0202',10028,4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-1ZZ0202',10030,3);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-1ZZ0202',10031,0);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-1ZZ0202',10033,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-1ZZ0202',10038,16.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-1ZZ0202',10039,18);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-1ZZ0202',10046,19);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-1ZZ0202',10049,17);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-1ZZ0202',10054,7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-1ZZ0202',10060,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-1ZZ0202',10069,2.1);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-1ZZ0202',10070,19);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-1ZZ0202',10072,15.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-1ZZ0202',10087,12);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-1ZZ0202',10091,11.8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-1ZZ0202',10097,18.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-1ZZ0201',10002,18);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-1ZZ0201',10007,12.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-1ZZ0201',10010,11);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-1ZZ0201',10016,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-1ZZ0201',10028,1);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-1ZZ0201',10030,9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-1ZZ0201',10031,0);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-1ZZ0201',10033,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-1ZZ0201',10038,14.6);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-1ZZ0201',10039,19);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-1ZZ0201',10046,17);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-1ZZ0201',10049,11);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-1ZZ0201',10054,6);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-1ZZ0201',10060,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-1ZZ0201',10069,5.2);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-1ZZ0201',10070,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-1ZZ0201',10072,18);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-1ZZ0201',10087,14);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-1ZZ0201',10091,14.8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-1ZZ0201',10097,11.5);
 INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1101',10002,8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1101',10007,11);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1101',10010,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1101',10016,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1101',10028,9.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1101',10030,7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1101',10031,0);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1101',10033,12);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1101',10038,18);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1101',10039,19);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1101',10046,11.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1101',10049,12);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1101',10054,13);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1101',10060,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1101',10069,1.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1101',10070,14);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1101',10072,14.6);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1101',10087,8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1101',10091,18);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1101',10097,17);
 INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1102',10002,14);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1102',10007,18);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1102',10010,17);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1102',10016,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1102',10028,7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1102',10030,9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1102',10031,0);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1102',10033,11);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1102',10038,17);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1102',10039,12);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1102',10046,11);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1102',10049,14.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1102',10054,12.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1102',10060,17);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1102',10069,4.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1102',10070,19);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1102',10072,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1102',10087,5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1102',10091,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1102',10097,13.9);
 INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1303',10002,11);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1303',10007,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1303',10010,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1303',10016,13);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1303',10028,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1303',10030,9.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1303',10031,0);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1303',10033,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1303',10038,19);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1303',10039,14);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1303',10046,12);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1303',10049,16.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1303',10054,18.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1303',10060,14.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1303',10069,2.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1303',10070,16.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1303',10072,17.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1303',10087,4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1303',10091,17.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1303',10097,13.8);
  INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1302',10002,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1302',10007,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1302',10010,17);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1302',10016,12.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1302',10028,14.8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1302',10030,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1302',10031,5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1302',10033,18.3);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1302',10038,18.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1302',10039,16.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1302',10046,13.8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1302',10049,19.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1302',10054,14.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1302',10060,17.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1302',10069,8.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1302',10070,11.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1302',10072,13.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1302',10087,8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1302',10091,19.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1302',10097,18.8);
  INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1301',10002,17.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1301',10007,12.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1301',10010,13.8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1301',10016,15.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1301',10028,19.8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1301',10030,11.3);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1301',10031,8.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1301',10033,8.3);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1301',10038,4.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1301',10039,6.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1301',10046,15.8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1301',10049,16.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1301',10054,15.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1301',10060,19.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1301',10069,10.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1301',10070,15.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-2ZZ1301',10072,14.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1301',10087,9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-2ZZ1301',10091,16.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-2ZZ1301',10097,19.8);
  INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0402',10002,20);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0402',10007,18);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0402',10010,13);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0402',10016,14.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0402',10028,12.8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0402',10030,14.3);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0402',10031,19.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0402',10033,18.3);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0402',10038,15.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0402',10039,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0402',10046,12.8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0402',10049,11.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0402',10054,12.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0402',10060,14.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0402',10069,15.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0402',10070,17.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0402',10072,19.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0402',10087,18);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0402',10091,12.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0402',10097,14);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0403',10002,11);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0403',10007,12.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0403',10010,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0403',10016,16);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0403',10028,18.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0403',10030,13.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0403',10031,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0403',10033,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0403',10038,16.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0403',10039,17.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0403',10046,14.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0403',10049,11.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0403',10054,13.1);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0403',10060,11.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0403',10069,19.2);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0403',10070,10.3);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0403',10072,17.2);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0403',10087,10.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0403',10091,19.2);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0403',10097,16.6);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0401',10002,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0401',10007,18.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0401',10010,17.6);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0401',10016,18.1);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0401',10028,12.2);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0401',10030,14.3);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0401',10031,13);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0401',10033,14);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0401',10038,15.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0401',10039,16.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0401',10046,18.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0401',10049,17);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0401',10054,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0401',10060,19.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0401',10069,14.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0401',10070,11.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0401',10072,14.8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0401',10087,12.3);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0401',10091,12.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0401',10097,18.8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0404',10002,12.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0404',10007,15.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0404',10010,12.6);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0404',10016,11.1);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0404',10028,15.2);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0404',10030,19.3);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0404',10031,11);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0404',10033,18);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0404',10038,11.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0404',10039,14.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0404',10046,15.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0404',10049,19.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0404',10054,13);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0404',10060,14.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0404',10069,16.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0404',10070,18.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0404',10072,12.8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0404',10087,13.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0404',10091,15.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0404',10097,19.8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0502',10002,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0502',10007,13);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0502',10010,17);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0502',10016,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0502',10028,11);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0502',10030,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0502',10031,14);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0502',10033,13);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0502',10038,14.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0502',10039,17.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0502',10046,18.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0502',10049,15.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0502',10054,17);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0502',10060,18.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0502',10069,19.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0502',10070,15.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0502',10072,14.8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0502',10087,11.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0502',10091,12.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0502',10097,18.8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0503',10002,11);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0503',10007,12.8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0503',10010,14.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0503',10016,11.2);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0503',10028,13.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0503',10030,14.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0503',10031,16.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0503',10033,11.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0503',10038,18.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0503',10039,12.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0503',10046,17);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0503',10049,16);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0503',10054,11.1);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0503',10060,10.1);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0503',10069,17.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0503',10070,14.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0503',10072,19);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0503',10087,20);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0503',10091,16.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0503',10097,19.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0501',10002,12);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0501',10007,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0501',10010,13);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0501',10016,18);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0501',10028,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0501',10030,13.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0501',10031,14.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0501',10033,15.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0501',10038,17);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0501',10039,12.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0501',10046,19);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0501',10049,15.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0501',10054,13.3);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0501',10060,11.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0501',10069,15.6);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0501',10070,13.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('1-3ZZ0501',10072,17.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0501',10087,17.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3ZZ0501',10091,15.1);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3ZZ0501',10097,16.2);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3YY0102',10016,13.6);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3YY0102',10030,11);
 INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3YY0102',10031,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3YY0102',10038,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3YY0102',10070,14.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3YY0102',10087,15.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3YY0102',10091,18.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3YY0102',10010,17.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3YY0102',10049,19.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3YY0102',10054,14.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3YY0102',10069,11.2);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3YY0101',10016,19.6);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3YY0101',10030,10.5);
 INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3YY0101',10031,12.1);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3YY0101',10038,14.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3YY0101',10070,13.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('1-3YY0101',10087,12.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3YY0101',10091,11.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3YY0101',10010,16);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3YY0101',10049,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3YY0101',10054,13);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('1-3YY0101',10069,17);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('2-3GE0401',10002,17.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('2-3GE0402',10002,11.1);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('2-3CH0401',10007,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('2-3CH0402',10007,11);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3GT0501',10010,18.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3GT0502',10010,15.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3GT0503',10010,16);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('2-3EM1001',10016,14.3);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('2-3EM1002',10016,18.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('2-3EM1003',10016,15.3);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('2-3CH0401',10028,11);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('2-3CH0402',10028,14);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('2-3EM1001',10030,13);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('2-3EM1002',10030,15.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('2-3EM1003',10030,17.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3EM1001',10031,11);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3EM1002',10031,14);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3EM1003',10031,18);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3CH0401',10033,13);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3CH0402',10033,17.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3EM1001',10038,14.2);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3EM1002',10038,16.6);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3EM1003',10038,10.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('2-3GE0401',10039,19.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('2-3GE0402',10039,14.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('2-3CH0401',10046,17);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('2-3CH0402',10046,18);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3GT0501',10049,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3GT0502',10049,14);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3GT0503',10049,12.5);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3GT0501',10054,2.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3GT0502',10054,15);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3GT0503',10054,14);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('2-3CH0401',10060,15.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('2-3CH0402',10060,11.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('2-3GT0501',10069,8.1);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('2-3GT0502',10069,17.7);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('2-3GT0503',10069,18);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3EM1001',10070,13.1);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3EM1002',10070,16.8);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3EM1003',10070,19.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('2-3CH0401',10072,10);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
VALUES ('2-3CH0402',10072,11);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('2-3EM1001',10087,12.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('2-3EM1002',10087,15.4);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('2-3EM1003',10087,18.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3EM1001',10091,14.6);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3EM1002',10091,18);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes)  
VALUES ('2-3EM1003',10091,19);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('2-3CH0401',10097,18.9);
INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) 
 VALUES ('2-3CH0402',10097,15.7);
#cavp
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10002-1','2017/2018',10002,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10007-1','2017/2018',10007,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10010-1','2017/2018',10010,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10016-1','2017/2018',10016,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10028-1','2017/2018',10028,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10030-1','2017/2018',10030,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
VALUES ('10031-1','2017/2018',10031,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10033-1','2017/2018',10033,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10038-1','2017/2018',10038,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc) 
VALUES ('10039-1','2017/2018',10039,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10046-1','2017/2018',10046,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10049-1','2017/2018',10049,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10054-1','2017/2018',10054,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10060-1','2017/2018',10060,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
VALUES ('10069-1','2017/2018',10069,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
VALUES ('10070-1','2017/2018',10070,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc) 
VALUES ('10072-1','2017/2018',10072,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
VALUES ('10087-1','2017/2018',10087,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
VALUES ('10091-1','2017/2018',10091,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10097-1','2017/2018',10097,'no-section','BLOC1');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
VALUES ('10002-2','2018/2019',10002,'GE','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
VALUES ('10007-2','2018/2019',10007,'CH','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10010-2','2018/2019',10010,'GT','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10016-2','2018/2019',10016,'EM','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10028-2','2018/2019',10028,'CH','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10030-2','2018/2019',10030,'EM','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10031-2','2018/2019',10031,'EM','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10033-2','2018/2019',10033,'CH','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10038-2','2018/2019',10038,'EM','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
VALUES ('10039-2','2018/2019',10039,'GE','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
VALUES ('10046-2','2018/2019',10046,'CH','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10049-2','2018/2019',10049,'GT','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10054-2','2018/2019',10054,'GT','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10060-2','2018/2019',10060,'CH','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc) 
VALUES ('10069-2','2018/2019',10069,'GT','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10070-2','2018/2019',10070,'EM','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
VALUES ('10072-2','2018/2019',10072,'CH','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
VALUES ('10087-2','2018/2019',10087,'EM','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
VALUES ('10091-2','2018/2019',10091,'EM','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
VALUES ('10097-2','2018/2019',10097,'CH','BLOC2');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10002-3','2019/2020',10002,'GE','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10007-3','2019/2020',10007,'CH','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10010-3','2019/2020',10010,'GT','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10016-3','2019/2020',10016,'EM','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10028-3','2019/2020',10028,'CH','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10030-3','2019/2020',10030,'EM','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10031-3','2019/2020',10031,'EM','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10033-3','2019/2020',10033,'CH','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10038-3','2019/2020',10038,'EM','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10039-3','2019/2020',10039,'GE','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10046-3','2019/2020',10046,'CH','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10049-3','2019/2020',10049,'GT','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10054-3','2019/2020',10054,'GT','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10060-3','2019/2020',10060,'CH','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10069-3','2019/2020',10069,'GT','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10070-3','2019/2020',10070,'EM','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10072-3','2019/2020',10072,'CH','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10087-3','2019/2020',10087,'EM','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10091-3','2019/2020',10091,'EM','BLOC3');
INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca,section,bloc)
 VALUES ('10097-3','2019/2020',10097,'CH','BLOC3');
#appartient
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('1ZZ0200','10002-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1100','10002-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('2ZZ1300','10002-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3GE0400','10002-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3YY0600','10002-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0400','10002-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0500','10002-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('1ZZ0200','10007-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1100','10007-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('2ZZ1300','10007-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3CH0400','10007-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3YY0600','10007-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0400','10007-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0500','10007-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('1ZZ0200','10010-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('2ZZ1100','10010-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('2ZZ1300','10010-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3GT0500','10010-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3YY0100','10010-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0400','10010-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0500','10010-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('1ZZ0200','10016-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1100','10016-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1300','10016-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3EM1000','10016-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3YY0100','10016-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0400','10016-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0500','10016-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('1ZZ0200','10028-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1100','10028-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('2ZZ1300','10028-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3CH0400','10028-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3YY0600','10028-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0400','10028-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0500','10028-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('1ZZ0200','10030-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1100','10030-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1300','10030-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3EM1000','10030-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3YY0100','10030-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0400','10030-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0500','10030-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('1ZZ0200','10031-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1100','10031-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1300','10031-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3EM1000','10031-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3YY0100','10031-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0400','10031-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0500','10031-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('1ZZ0200','10033-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1100','10033-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1300','10033-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3CH0400','10033-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3YY0600','10033-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0400','10033-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0500','10033-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('1ZZ0200','10038-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1100','10038-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1300','10038-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3EM1000','10038-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3YY0100','10038-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0400','10038-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0500','10038-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('1ZZ0200','10039-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('2ZZ1100','10039-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('2ZZ1300','10039-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3GE0400','10039-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3YY0600','10039-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0400','10039-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0500','10039-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('1ZZ0200','10046-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('2ZZ1100','10046-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1300','10046-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3CH0400','10046-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3YY0600','10046-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0400','10046-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0500','10046-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('1ZZ0200','10049-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1100','10049-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1300','10049-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3GT0500','10049-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3YY0100','10049-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0400','10049-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0500','10049-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('1ZZ0200','10054-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('2ZZ1100','10054-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1300','10054-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3GT0500','10054-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3YY0100','10054-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0400','10054-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0500','10054-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('1ZZ0200','10060-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1100','10060-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('2ZZ1300','10060-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3CH0400','10060-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3YY0600','10060-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0400','10060-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0500','10060-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('1ZZ0200','10069-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1100','10069-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1300','10069-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3GT0500','10069-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3YY0100','10069-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0400','10069-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0500','10069-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('1ZZ0200','10070-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1100','10070-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1300','10070-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3EM1000','10070-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3YY0100','10070-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0400','10070-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0500','10070-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('1ZZ0200','10072-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('2ZZ1100','10072-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1300','10072-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3CH0400','10072-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3YY0600','10072-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0400','10072-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0500','10072-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('1ZZ0200','10087-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1100','10087-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('2ZZ1300','10087-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3EM1000','10087-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3YY0100','10087-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0400','10087-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0500','10087-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('1ZZ0200','10091-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1100','10091-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('2ZZ1300','10091-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3EM1000','10091-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3YY0100','10091-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0400','10091-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3ZZ0500','10091-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('1ZZ0200','10097-1');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1100','10097-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('2ZZ1300','10097-2');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3CH0400','10097-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
 VALUES ('3YY0600','10097-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0400','10097-3');
INSERT INTO appartient(UNumberUE,CNumeroCAVPEtud)
VALUES ('3ZZ0500','10097-3');




