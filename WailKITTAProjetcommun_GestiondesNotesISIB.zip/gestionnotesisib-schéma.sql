DROP DATABASE IF EXISTS gestionnotesisib;
CREATE DATABASE gestionnotesisib;
USE gestionnotesisib;

 Drop TABLE if exists UE;
  Create table UE(
  NumberUE CHAR(7) not null,
  NameUE varchar(40) not null,
  CreditsUE int NOT NULL,
  HeuresUE int NOT NULL,
  Primary key (NumberUE)
  );

  Drop TABLE if exists Etudiant;
  Create table Etudiant(
  NumberEtud int not null,
  NomEtud varchar(20) not null,
  PrénomEtud varchar(20) not null,
  AdresseEtud varchar(30) ,
  DatedeNaissEtud date ,
  SexeEtud char(1),
  Primary key ( NumberEtud)
  );  

  
  Drop TABLE if exists Professeurs;
  Create table Professeurs(
  NomProf varchar(20)not null,
  PrenomProf varchar (20)not null,
  ProfAdresse varchar (30)not null,
  SexeProf char(1),
  Primary key (NomProf,PrenomProf));
  
 DROP TABLE IF EXISTS Sessions;
CREATE TABLE Sessions (
  NuméroSess CHAR(9) NOT NULL, 
  Année int not null ,
  PRIMARY KEY (NuméroSess));
  
  DROP TABLE IF EXISTS participe;
   Create table participe(
  SNuméroSess CHAR(9) NOT NULL, 
  PNomProf varchar(20)not null,
  PPrenomProf varchar (20)not null,
  Primary key (SNuméroSess,PNomProf,PPrenomProf),
  Foreign key (SNuméroSess) References Sessions (NuméroSess),
  FOREIGN KEY (PNomProf,PPrenomProf) REFERENCES Professeurs(NomProf,PrenomProf ));
  
   DROP TABLE IF EXISTS Cours;
CREATE TABLE Cours (
  NumberAA CHAR(7) NOT NULL,
  NameAA VARCHAR(50) NOT NULL,
  Hours INT NOT NULL,
  CreditsAA INT NOT NULL,
  UNumberUE CHAR(7) not null,
  SNuméroSess CHAR(9) NOT NULL, 
  PRIMARY KEY (NumberAA,UNumberUE, SNuméroSess),
  Foreign key (UNumberUE) References UE (NumberUE),
   Foreign key (SNuméroSess) References Sessions (NuméroSess)
   );
   
  Drop TABLE if exists Résultats;
  Create table Résultats(
  SNuméroSess CHAR(9) NOT NULL, 
  ENumberEtud int NOT NULL,
  Notes float,
  Primary key (SNuméroSess, ENumberEtud),
  Foreign key (SNuméroSess) References Sessions (NuméroSess),
  Foreign key (ENumberEtud) References Etudiant (NumberEtud));
  
  
  Drop TABLE if exists CAVP;
  Create table CAVP(
  NumeroCAVPEtud char(7) NOT NULL, 
  Annéeacademique char(9) NOT NULL,
  Ca int NOT NULL,
  section varchar(11),
  bloc varchar(6),
  Primary key (NumeroCAVPEtud, Ca),
  Foreign key (Ca) References  Etudiant (NumberEtud));
  
  Drop TABLE if exists appartient;
  Create table appartient(
  UNumberUE CHAR(7) not null,
  CNumeroCAVPEtud char(7) NOT NULL, 
  Primary key (UNumberUE,CNumeroCAVPEtud),
  Foreign key (UNumberUE) References UE (NumberUE),
  Foreign key (CNumeroCAVPEtud) References CAVP (NumeroCAVPEtud));
  
