
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Wail_
 */
public class Panell extends JPanel {

    public Panell() throws SQLException {

        JTextArea textArea = new JTextArea(20, 20);

        JComboBox<String> comboBox = new JComboBox<String>();
        comboBox.addItem("appartient");
        comboBox.addItem("cavp");
        comboBox.addItem("cours");
        comboBox.addItem("Etudiant");
        comboBox.addItem("Professeurs");
        comboBox.addItem("UE");
        comboBox.addItem("Résultats");
        comboBox.addItem("Sessions");
        comboBox.addItem("participe");
        comboBox.addItem("Notes cycles");
        comboBox.addItem("cavp affichage");
        comboBox.addItem("Notes annuelle");
        comboBox.addItem("Notes examen une AA");
        comboBox.addItem("Création Session");
        comboBox.addItem("Encodage AA");
        comboBox.addItem("Création CAVP");

        JButton button = new JButton("Reset");
        JTextField text = new JTextField(20);
        JTextField text2 = new JTextField(20);
        JTextField text3 = new JTextField(20);
        JButton button2 = new JButton("Ok");
        text.disable();
        text2.disable();
        text3.disable();
        button2.disable();
        comboBox.addItemListener(new ItemListener() {

            public void itemStateChanged(ItemEvent ie) {
                String url = "jdbc:mysql://127.0.0.1:3306/gestionnotesisib?serverTimezone=UTC";
                String username = "root";
                String password = "isib";
                Connection con2 = null;
                try {
                    con2 = DriverManager.getConnection(url, username, password);
                } catch (SQLException ex) {
                    Logger.getLogger(Panell.class.getName()).log(Level.SEVERE, null, ex);
                }

                if (ie.getStateChange() == ItemEvent.SELECTED) {
                    ie.getSource();
                    String s = (String) comboBox.getSelectedItem();
                    if (s.equals("appartient")) {
                         text.disable();
                        text2.disable();
                        text3.disable();
                        button2.disable();
                        ResultSet résultats = null;
                        String requete = "SELECT * FROM appartient ";
                        try {
                            Statement stmt = con2.createStatement();
                            résultats = stmt.executeQuery(requete);
                            while (résultats.next()) {
                                textArea.append("----------------------------------------------------\n");
                                textArea.append("UNumberUE:" + résultats.getString("UNumberUE") + "\n");
                                textArea.append("CNumeroCAVPEtud:" + résultats.getString("CNumeroCAVPEtud") + "\n");
                            }

                        } catch (SQLException e) {
                            e.printStackTrace();
                        };

                    }

                    if (s.equals("cavp")) {
                         text.disable();
                        text2.disable();
                        text3.disable();
                        button2.disable();
                        ResultSet résultats = null;
                        String requete = "SELECT * FROM cavp ";
                        try {
                            Statement stmt = con2.createStatement();
                            résultats = stmt.executeQuery(requete);
                            while (résultats.next()) {
                                textArea.append("----------------------------------------------------\n");
                                textArea.append("NumeroCAVPEtud:" + résultats.getString("NumeroCAVPEtud") + "\n");
                                textArea.append("Annéeacademique:" + résultats.getString("Annéeacademique") + "\n");
                                textArea.append("Ca:" + résultats.getInt("Ca") + "\n");
                                textArea.append("section:" + résultats.getString("section") + "\n");
                                textArea.append("bloc:" + résultats.getString("bloc") + "\n");
                            }

                        } catch (SQLException e) {
                            e.printStackTrace();
                        };
                    }
                    if (s.equals("cours")) {
                         text.disable();
                        text2.disable();
                        text3.disable();
                        button2.disable();
                        ResultSet résultats = null;
                        String requete = "SELECT * FROM cours ";
                        try {
                            Statement stmt = con2.createStatement();
                            résultats = stmt.executeQuery(requete);
                            while (résultats.next()) {
                                textArea.append("----------------------------------------------------\n");
                                textArea.append("NumberAA:" + résultats.getString("NumberAA") + "\n");
                                textArea.append("NameAA:" + résultats.getString("NameAA") + "\n");
                                textArea.append("Hours:" + résultats.getInt("Hours") + "\n");
                                textArea.append("CreditsAA:" + résultats.getInt("CreditsAA") + "\n");
                                textArea.append("UNumberUE:" + résultats.getString("UNumberUE") + "\n");
                                textArea.append("SNuméroSess:" + résultats.getString("SNuméroSess") + "\n");
                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                    if (s.equals("Etudiant")) {
                         text.disable();
                        text2.disable();
                        text3.disable();
                        button2.disable();
                        ResultSet résultats = null;
                        String requete = "SELECT * FROM Etudiant ";
                        try {
                            Statement stmt = con2.createStatement();
                            résultats = stmt.executeQuery(requete);
                            while (résultats.next()) {
                                textArea.append("----------------------------------------------------\n");
                                textArea.append("NumberEtud:" + résultats.getInt("NumberEtud") + "\n");
                                textArea.append("NomEtud:" + résultats.getString("NomEtud") + "\n");
                                textArea.append("PrénomEtud:" + résultats.getString("PrénomEtud") + "\n");
                                textArea.append("AdresseEtud:" + résultats.getString("AdresseEtud") + "\n");
                                textArea.append("DatedeNaissEtud:" + résultats.getDate("DatedeNaissEtud") + "\n");
                                textArea.append("SexeEtud:" + résultats.getString("SexeEtud") + "\n");
                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }

                    if (s.equals("Professeurs")) {
                         text.disable();
                        text2.disable();
                        text3.disable();
                        button2.disable();
                        ResultSet résultats = null;
                        String requete = "SELECT * FROM Professeurs ";
                        try {
                            Statement stmt = con2.createStatement();
                            résultats = stmt.executeQuery(requete);
                            while (résultats.next()) {
                                textArea.append("----------------------------------------------------\n");
                                textArea.append("NomProf:" + résultats.getString("NomProf") + "\n");
                                textArea.append("PrenomProf:" + résultats.getString("PrenomProf") + "\n");
                                textArea.append("ProfAdresse:" + résultats.getString("ProfAdresse") + "\n");
                                textArea.append("SexeProf:" + résultats.getString("SexeProf") + "\n");
                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                    if (s.equals("UE")) {
                         text.disable();
                        text2.disable();
                        text3.disable();
                        button2.disable();
                        ResultSet résultats = null;
                        String requete = "SELECT * FROM UE ";
                        try {
                            Statement stmt = con2.createStatement();
                            résultats = stmt.executeQuery(requete);
                            while (résultats.next()) {
                                textArea.append("----------------------------------------------------\n");
                                textArea.append("NumberUE:" + résultats.getString("NumberUE") + "\n");
                                textArea.append("NameUE:" + résultats.getString("NameUE") + "\n");
                                textArea.append("CreditsUE:" + résultats.getInt("CreditsUE") + "\n");
                                textArea.append("HeuresUE:" + résultats.getInt("HeuresUE") + "\n");
                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                    if (s.equals("Résultats")) {
                         text.disable();
                        text2.disable();
                        text3.disable();
                        button2.disable();
                        ResultSet résultats = null;
                        String requete = "SELECT * FROM Résultats ";
                        try {
                            Statement stmt = con2.createStatement();
                            résultats = stmt.executeQuery(requete);
                            while (résultats.next()) {
                                textArea.append("----------------------------------------------------\n");
                                textArea.append("SNuméroSess:" + résultats.getString("SNuméroSess") + "\n");
                                textArea.append("ENumberEtud:" + résultats.getInt("ENumberEtud") + "\n");
                                textArea.append("Notes:" + résultats.getFloat("Notes") + "\n");
                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                    if (s.equals("Sessions")) {
                         text.disable();
                        text2.disable();
                        text3.disable();
                        button2.disable();
                        ResultSet résultats = null;
                        String requete = "SELECT * FROM Sessions ";
                        try {
                            Statement stmt = con2.createStatement();
                            résultats = stmt.executeQuery(requete);
                            while (résultats.next()) {
                                textArea.append("----------------------------------------------------\n");
                                textArea.append("NuméroSess:" + résultats.getString("NuméroSess") + "\n");
                                textArea.append("Année:" + résultats.getInt("Année") + "\n");
                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                    if (s.equals("participe")) {
                         text.disable();
                        text2.disable();
                        text3.disable();
                        button2.disable();
                        ResultSet résultats = null;
                        String requete = "SELECT * FROM participe ";
                        try {
                            Statement stmt = con2.createStatement();
                            résultats = stmt.executeQuery(requete);
                            while (résultats.next()) {
                                textArea.append("----------------------------------------------------\n");
                                textArea.append("SNuméroSess:" + résultats.getString("SNuméroSess") + "\n");
                                textArea.append("PNomProf:" + résultats.getString("PNomProf") + "\n");
                                textArea.append("PPrenomProf:" + résultats.getString("PPrenomProf") + "\n");
                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                    if (s.equals("Notes cycles")) {
                        text.enable();
                        text2.disable();
                        text3.disable();
                        button2.enable();
                        
                        button2.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                String url = "jdbc:mysql://127.0.0.1:3306/gestionnotesisib?serverTimezone=UTC";
                                String username = "root";
                                String password = "isib";
                                Connection con2 = null;
                                try {
                                    con2 = DriverManager.getConnection(url, username, password);
                                } catch (SQLException ex) {
                                    Logger.getLogger(Panell.class.getName()).log(Level.SEVERE, null, ex);
                                }
                                ResultSet résultats = null;
                                String requete = "select NomEtud,PrénomEtud,Année,NuméroSess,Notes\n"
                                + "from etudiant e inner join résultats r on e.NumberEtud=r.ENumberEtud\n"
                                + "inner join Sessions s on r.SNuméroSess=s.NuméroSess\n"
                                + "where e.NumberEtud ="+ text.getText();
                                try {
                                    Statement stmt = con2.createStatement();
                                    résultats=stmt.executeQuery(requete);
                                    while (résultats.next()) {
                                         textArea.append("----------------------------------------------------\n");
                                         textArea.append("NomEtud:" + résultats.getString("NomEtud") + "\n");
                                         textArea.append("PrénomEtud:" + résultats.getString("PrénomEtud") + "\n");
                                         textArea.append("Année:" + résultats.getString("Année") + "\n");
                                         textArea.append("NuméroSess:" + résultats.getString("NuméroSess") + "\n");
                                         textArea.append("Notes:" + résultats.getFloat("Notes") + "\n");
                                    }
                                    
                                } catch (SQLException e) {
                                    e.printStackTrace();
                                }
                    }
                        });
                    }
                    if (s.equals("cavp affichage")) {
                        text.enable();
                        text2.disable();
                        text3.disable();
                        button2.enable();
                        
                        button2.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                String url = "jdbc:mysql://127.0.0.1:3306/gestionnotesisib?serverTimezone=UTC";
                                String username = "root";
                                String password = "isib";
                                Connection con2 = null;
                                try {
                                    con2 = DriverManager.getConnection(url, username, password);
                                } catch (SQLException ex) {
                                    Logger.getLogger(Panell.class.getName()).log(Level.SEVERE, null, ex);
                                }
                                ResultSet résultats = null;
                                String requete = "select NumeroCAVPEtud,NomEtud,PrénomEtud,Annéeacademique\n"
                                + "from cavp c inner join etudiant e on c.Ca=e.NumberEtud\n"
                                + "where e.NumberEtud ="+text.getText();
                                try {
                                    Statement stmt = con2.createStatement();
                                    résultats=stmt.executeQuery(requete);
                                    while (résultats.next()) {
                                         textArea.append("----------------------------------------------------\n");
                                         textArea.append("NumeroCAVPEtud:" + résultats.getString("NumeroCAVPEtud") + "\n");
                                         textArea.append("NomEtud:" + résultats.getString("NomEtud") + "\n");
                                         textArea.append("PrénomEtud:" + résultats.getString("PrénomEtud") + "\n");
                                         textArea.append("Annéeacademique:" + résultats.getString("Annéeacademique") + "\n");
                                    }
                                    
                                } catch (SQLException e) {
                                    e.printStackTrace();
                                }
                    }
                        });
                    }
                    if (s.equals("Notes annuelle")) {
                        text.enable();
                        text2.enable();
                        text3.disable();
                        button2.enable();
                        
                        button2.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                String url = "jdbc:mysql://127.0.0.1:3306/gestionnotesisib?serverTimezone=UTC";
                                String username = "root";
                                String password = "isib";
                                Connection con2 = null;
                                try {
                                    con2 = DriverManager.getConnection(url, username, password);
                                } catch (SQLException ex) {
                                    Logger.getLogger(Panell.class.getName()).log(Level.SEVERE, null, ex);
                                }
                                ResultSet résultats = null;
                                String requete = "select NomEtud,PrénomEtud,Année,NuméroSess,Notes\n"
                                + "from etudiant e inner join résultats r on e.NumberEtud=r.ENumberEtud\n"
                                + "inner join Sessions s on r.SNuméroSess=s.NuméroSess\n"
                                + "where e.NumberEtud ="+text.getText()+"and Année="+text2.getText();
                                try {
                                    Statement stmt = con2.createStatement();
                                    résultats=stmt.executeQuery(requete);
                                    while (résultats.next()) {
                                          textArea.append("----------------------------------------------------\n");
                                          textArea.append("NomEtud:" + résultats.getString("NomEtud") + "\n");
                                          textArea.append("PrénomEtud:" + résultats.getString("PrénomEtud") + "\n");
                                          textArea.append("Année:" + résultats.getString("Année") + "\n");
                                          textArea.append("NuméroSess:" + résultats.getString("NuméroSess") + "\n");
                                          textArea.append("Notes:" + résultats.getFloat("Notes") + "\n");
                                    }
                                    
                                } catch (SQLException e) {
                                    e.printStackTrace();
                                }
                    }
                        });
                    }
                    if (s.equals("Notes examen une AA")) {
                        text.enable();
                        text2.disable();
                        text3.disable();
                        button2.enable();
                        
                        button2.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                String url = "jdbc:mysql://127.0.0.1:3306/gestionnotesisib?serverTimezone=UTC";
                                String username = "root";
                                String password = "isib";
                                Connection con2 = null;
                                try {
                                    con2 = DriverManager.getConnection(url, username, password);
                                } catch (SQLException ex) {
                                    Logger.getLogger(Panell.class.getName()).log(Level.SEVERE, null, ex);
                                }
                                ResultSet résultats = null;
                                String requete = "select  PNomProf,PPrenomProf,NumberAA,Notes,NumberEtud\n"
                                + "from professeurs r inner join participe p on (r.NomProf=p.PNomProf and r.PrenomProf=p.PPrenomProf)\n"
                                + "inner join cours c on p.SNuméroSess=c.SNuméroSess\n"
                                + "inner join Résultats s on c.SNuméroSess=s.SNuméroSess\n"
                                + "inner join Etudiant e on s.ENumberEtud=e.NumberEtud\n"
                                + "where NameAA ='"+text.getText()+"'";
                                try {
                                    Statement stmt = con2.createStatement();
                                    résultats=stmt.executeQuery(requete);
                                    while (résultats.next()) {
                                        textArea.append("----------------------------------------------------\n");
                                        textArea.append("PNomProf:" + résultats.getString("PNomProf") + "\n");
                                        textArea.append("PPrenomProf:" + résultats.getString("PPrenomProf") + "\n");
                                        textArea.append("NumberAA:" + résultats.getString("NumberAA") + "\n");
                                        textArea.append("Notes:" + résultats.getFloat("Notes") + "\n");
                                        textArea.append("NumberEtud:" + résultats.getInt("NumberEtud") + "\n");
                                    }
                                    
                                } catch (SQLException e) {
                                    e.printStackTrace();
                                }
                    }
                        });
                    }
                    if (s.equals("Création CAVP")) {
                        text.enable();
                        text2.enable();
                        text3.enable();
                        button2.enable();
                        
                        button2.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                String url = "jdbc:mysql://127.0.0.1:3306/gestionnotesisib?serverTimezone=UTC";
                                String username = "root";
                                String password = "isib";
                                Connection con2 = null;
                                try {
                                    con2 = DriverManager.getConnection(url, username, password);
                                } catch (SQLException ex) {
                                    Logger.getLogger(Panell.class.getName()).log(Level.SEVERE, null, ex);
                                }
                                ResultSet résultats = null;
                                String requete = "INSERT INTO CAVP(NumeroCAVPEtud,Annéeacademique,Ca)\n"
                                + "VALUES ('"+text.getText()+"','"+text2.getText()+"',"+text3.getText()+")";
                                try {
                                    Statement stmt = con2.createStatement();
                                    stmt.executeUpdate(requete);
                                    textArea.append("Insert completed");
                                    
                                    
                                } catch (SQLException e) {
                                    e.printStackTrace();
                                }
                    }
                        });
                    }
                    if (s.equals("Création Session")) {
                        text.enable();
                        text2.enable();
                        text3.disable();
                        button2.enable();
                        
                        button2.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                String url = "jdbc:mysql://127.0.0.1:3306/gestionnotesisib?serverTimezone=UTC";
                                String username = "root";
                                String password = "isib";
                                Connection con2 = null;
                                try {
                                    con2 = DriverManager.getConnection(url, username, password);
                                } catch (SQLException ex) {
                                    Logger.getLogger(Panell.class.getName()).log(Level.SEVERE, null, ex);
                                }
                                ResultSet résultats = null;
                                String requete = "INSERT INTO Sessions (NuméroSess,Année) \n" +
                                "VALUES ('"+text.getText()+"',"+text2.getText()+')';
                                try {
                                    Statement stmt = con2.createStatement();
                                    stmt.executeUpdate(requete);
                                    textArea.append("Insert completed");
                                    
                                } catch (SQLException e) {
                                    e.printStackTrace();
                                }
                            }

                        });
                     }
                        if (s.equals("Encodage AA")) {
                        text.enable();
                        text2.enable();
                        text3.enable();
                        button2.enable();
                        
                        button2.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                String url = "jdbc:mysql://127.0.0.1:3306/gestionnotesisib?serverTimezone=UTC";
                                String username = "root";
                                String password = "isib";
                                Connection con2 = null;
                                try {
                                    con2 = DriverManager.getConnection(url, username, password);
                                } catch (SQLException ex) {
                                    Logger.getLogger(Panell.class.getName()).log(Level.SEVERE, null, ex);
                                }
                                ResultSet résultats = null;
                                String requete = "INSERT INTO Résultats (SNuméroSess,ENumberEtud,Notes) \n" +
                                "VALUES ('"+text.getText()+"',"+text2.getText()+","+text3.getText()+')';
                                try {
                                    Statement stmt = con2.createStatement();
                                    stmt.executeUpdate(requete);
                                    textArea.append("Insert completed");
                                    
                                } catch (SQLException e) {
                                    e.printStackTrace();
                                }
                            }

                        });
                     }
                }
            }

        }
        );
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textArea.setText(null);
                text.setText(null);
                text2.setText(null);
                
            }

        });
        button.addMouseListener(new MouseAdapter() { //car MouseAdapter contient les 3 méthodes et dans les sous méthodes elle peut les rendre à vide si on a pas besoin donc pas besoin de les écrire

            @Override
            public void mouseEntered(MouseEvent me) {
                button.setForeground(Color.RED);
            }

            @Override
            public void mouseExited(MouseEvent me) {
                button.setForeground(Color.BLACK);
            }

        });
        button2.addMouseListener(new MouseAdapter() { //car MouseAdapter contient les 3 méthodes et dans les sous méthodes elle peut les rendre à vide si on a pas besoin donc pas besoin de les écrire
            
            @Override
            public void mouseEntered(MouseEvent me) {
                button2.setForeground(Color.RED);
            }

            @Override
            public void mouseExited(MouseEvent me) {
                button2.setForeground(Color.BLACK);
            }

        });
        
        

        add(comboBox);
        add(text);
        add(text2);
        add(text3);
        add(button2);
        add(new JScrollPane(textArea));

        add(button);

    }

}
