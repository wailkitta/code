import pygame
import sys
import random

# Initialiser pygame
pygame.init()

# Dimensions de la fenêtre
WIDTH, HEIGHT = 600, 600
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Squadro")

# Couleurs
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREY = (200, 200, 200)
BLUE = (0, 0, 255)
RED = (255, 0, 0)

# Constantes du jeu
ROWS, COLS = 7, 7
SQUARE_SIZE = WIDTH // COLS


# Classe pour les pions
class Piece:
    def __init__(self, row, col, color, steps, angle=0):
        self.row = row
        self.col = col
        self.color = color
        self.steps = steps
        self.angle = angle
        self.direction = 1 if color == RED else -1
        self.returned = False
        self.initial_position = (row, col)

    def draw(self, win):
        rect_width = SQUARE_SIZE // 2
        rect_height = SQUARE_SIZE // 3
        rect_surface = pygame.Surface((rect_width, rect_height), pygame.SRCALPHA)
        rect_surface.fill(self.color)

        # Pivoter le rectangle
        rotated_surface = pygame.transform.rotate(rect_surface, self.angle)

        # Calculer la position de dessin pour centrer le pion
        x = self.col * SQUARE_SIZE + (SQUARE_SIZE - rotated_surface.get_width()) // 2
        y = self.row * SQUARE_SIZE + (SQUARE_SIZE - rotated_surface.get_height()) // 2

        # Dessiner le pion pivoté sur la fenêtre
        win.blit(rotated_surface, (x, y))

    def move(self):
        if self.color == RED:
            self.row += self.direction * self.steps
            if self.row >= ROWS or self.row < 0:
                self.row = max(0, min(ROWS - 1, self.row))
                self.direction *= -1
                if self.row == 0 or self.row == ROWS - 1:
                    self.returned = True
        else:
            self.col += self.direction * self.steps
            if self.col >= COLS or self.col < 0:
                self.col = max(0, min(COLS - 1, self.col))
                self.direction *= -1
                if self.col == 0 or self.col == COLS - 1:
                    self.returned = True


def evaluate(pieces):
#red_returned et blue_returned calculent respectivement le nombre de pièces rouges et bleues qui ont "retourné" à leur position initiale ou atteint leur objectif final.
    red_returned = sum(1 for piece in pieces if piece.color == RED and piece.returned)
    blue_returned = sum(1 for piece in pieces if piece.color == BLUE and piece.returned)


    blocking_value = 0 #cette est initialisé à 0 pour après accumulé la valeur totale de blocage entre les interactions des pièces
    for red_piece in pieces: # cette boucle va  permettre d'évaluer les interactions potentielles entre chaque paire de pièces rouge et bleue.
        if red_piece.color == RED:
            for blue_piece in pieces:
                if blue_piece.color == BLUE:
                    if (red_piece.row == blue_piece.row and abs(red_piece.col - blue_piece.col) <= red_piece.steps) or \
                            (red_piece.col == blue_piece.col and abs(
                                red_piece.row - blue_piece.row) <= red_piece.steps):
                        blocking_value += 10 #Si l'une des conditions de blocage est remplie, blocking_value += 10

    red_progress = sum(piece.row for piece in pieces if piece.color == RED)
    blue_progress = sum(piece.col for piece in pieces if piece.color == BLUE)

    return (red_returned - blue_returned) * 10 + blocking_value + (red_progress - blue_progress)


def minimax(pieces, depth, alpha, beta, maximizingPlayer):
    if depth == 0 or is_game_over(pieces):
        return evaluate(pieces)
    if maximizingPlayer: #Si c'est le tour du joueur maximisant
        maxEval = float('-inf') # on initialise maxEval à -inf car c'est la valeur la plus basse pour qu'on puisse trouver une valeur plus élevé
        for piece in pieces:
            if piece.color == RED and not piece.returned:
                original_pos = piece.row, piece.col #sauvegarde la position initiale
                piece.move()
                eval = minimax(pieces, depth - 1, alpha, beta, False)
                piece.row, piece.col = original_pos
                piece.returned = False
                piece.direction = 1
                maxEval = max(maxEval, eval) # ici on prend la meilleure valeur entre la valeur maxEval et eval
                alpha = max(alpha, eval) # represente la meilleur valeur que le joueur maximisant peut garantir
                if beta <= alpha: #ca veut dire que le joeur minimisant a une meilleur option ailleurs.
                    break
        return maxEval
    else:
        minEval = float('inf') # on initialise maxEval à inf car c'est la valeur la plus grande pour qu'on puisse trouver une valeur plus basse
        for piece in pieces:
            if piece.color == BLUE and not piece.returned:
                original_pos = piece.row, piece.col
                piece.move()
                eval = minimax(pieces, depth - 1, alpha, beta, True)
                piece.row, piece.col = original_pos  # Undo move
                piece.returned = False
                piece.direction = -1
                minEval = min(minEval, eval) # ici on prend la plus basse valeur entre la valeur minEval et eval
                beta = min(beta, eval) # represente la plus petite valeur que le joueur minimisant peut garantir
                if beta <= alpha:
                    break
        return minEval


def is_game_over(pieces):
    return all(piece.returned for piece in pieces)


def draw_board(win):
    win.fill(WHITE)
    for row in range(ROWS):
        for col in range(COLS):
            pygame.draw.rect(win, GREY, (col * SQUARE_SIZE, row * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE), 1)
            if (row, col) in [(0, 1), (0, 5)]:  # Spécifiez les coordonnées des cases où vous voulez dessiner les points
                point_radius = 3
                point_color = BLACK
                # Dessine un point au centre de la case
                pygame.draw.circle(win, point_color, (col * SQUARE_SIZE + SQUARE_SIZE - point_radius, row * SQUARE_SIZE + point_radius), point_radius)
            if (row, col) == (0, 3):  # Spécifie les coordonnées des cases où vous voulez dessiner les points
                point_radius = 3
                point_color = BLACK
                # Dessine plusieurs points dans la rangée spécifique
                start_x = col * SQUARE_SIZE + SQUARE_SIZE - point_radius  # Coordonnée x de départ
                start_y = row * SQUARE_SIZE + point_radius  # Coordonnée y de départ
                spacing = 10  # Espacement entre les points
                num_points = 2  # Nombre de points à dessiner
                for i in range(num_points):
                    point_y = start_y + i * spacing  # Calculer la coordonnée x du point actuel
                    pygame.draw.circle(win, point_color, (start_x, point_y), point_radius)
            if (row, col) in [(0, 2), (0, 4)]:
                point_radius = 3
                point_color = BLACK
                start_x = col * SQUARE_SIZE + SQUARE_SIZE - point_radius
                start_y = row * SQUARE_SIZE + point_radius
                spacing = 10
                num_points = 3
                for i in range(num_points):
                    point_y = start_y + i * spacing  # Calculer la coordonnée x du point actuel
                    pygame.draw.circle(win, point_color, (start_x, point_y), point_radius)
            if (row, col) in [(1,6),(5,6)]:
                point_radius = 3
                point_color = BLACK
                start_x = col * SQUARE_SIZE + SQUARE_SIZE  - point_radius
                start_y = row * SQUARE_SIZE  + point_radius
                spacing = 10
                num_points = 3
                for i in range(num_points):
                    point_y = start_y + i * spacing
                    pygame.draw.circle(win, point_color, (start_x, point_y), point_radius)
            if (row, col) in [(2,6),(4,6)]:
                point_radius = 3
                point_color = BLACK
                pygame.draw.circle(win, point_color,(col * SQUARE_SIZE + SQUARE_SIZE - point_radius, row * SQUARE_SIZE + point_radius),point_radius)
            if (row, col) == (3,6):
                point_radius = 3
                point_color = BLACK
                start_x = col * SQUARE_SIZE + SQUARE_SIZE  - point_radius
                start_y = row * SQUARE_SIZE  + point_radius
                spacing = 10
                num_points = 2
                for i in range(num_points):
                    point_y = start_y + i * spacing
                    pygame.draw.circle(win, point_color, (start_x, point_y), point_radius)



def get_clicked_square(mouse_pos):
    x, y = mouse_pos
    row = y // SQUARE_SIZE
    col = x // SQUARE_SIZE
    return row, col


def check_collision(pieces, current_piece):
    for piece in pieces:
        if piece != current_piece and piece.row == current_piece.row and piece.col == current_piece.col:
            return piece
    return None


def main():
    run = True
    clock = pygame.time.Clock()

    # Initialiser les pions des deux joueurs
    pieces = [
        Piece(0, 1, RED, 1, 90), Piece(0, 2, RED, 3, 90), Piece(0, 3, RED, 2, 90), Piece(0, 4, RED, 3, 90),
        Piece(0, 5, RED, 1, 90),
        Piece(1, 6, BLUE, 3), Piece(2, 6, BLUE, 1), Piece(3, 6, BLUE, 2), Piece(4, 6, BLUE, 1), Piece(5, 6, BLUE, 3)
    ]

    selected_piece = None
    current_player = RED  # Rouge commence

    while run:
        clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            elif event.type == pygame.MOUSEBUTTONDOWN and current_player == BLUE:  # Human player
                mouse_pos = pygame.mouse.get_pos()
                clicked_row, clicked_col = get_clicked_square(mouse_pos)
                for piece in pieces:
                    if piece.row == clicked_row and piece.col == clicked_col and piece.color == current_player:
                        selected_piece = piece
                        break
            elif event.type == pygame.MOUSEBUTTONUP and selected_piece and current_player == BLUE:
                selected_piece.move()
                collided_piece = check_collision(pieces, selected_piece)
                if collided_piece:
                    collided_piece.row, collided_piece.col = collided_piece.initial_position
                    collided_piece.direction = 1 if collided_piece.color == RED else -1
                    collided_piece.returned = False
                selected_piece = None
                current_player = RED if current_player == BLUE else BLUE

        if current_player == RED:  # tour de  l'IA
            best_moves = []
            best_value = float('-inf')
            for piece in pieces:
                if piece.color == RED and not piece.returned:
                    original_pos = piece.row, piece.col
                    piece.move()
                    move_value = minimax(pieces, 3, float('-inf'), float('inf'), False)
                    piece.row, piece.col = original_pos
                    piece.returned = False
                    piece.direction = 1
                    if move_value > best_value:
                        best_value = move_value
                        best_moves = [(piece, original_pos)]
                    elif move_value == best_value:
                        best_moves.append((piece, original_pos))

            if best_moves:
                best_piece, best_pos = random.choice(best_moves)
                best_piece.move()
                collided_piece = check_collision(pieces, best_piece)
                if collided_piece:
                    collided_piece.row, collided_piece.col = collided_piece.initial_position
                    collided_piece.direction = 1 if collided_piece.color == RED else -1
                    collided_piece.returned = False
                current_player = BLUE

        draw_board(WIN)
        for piece in pieces:
            piece.draw(WIN)

        pygame.display.update()

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()